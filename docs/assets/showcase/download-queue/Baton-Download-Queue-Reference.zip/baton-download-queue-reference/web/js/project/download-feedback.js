import { openDownloadReceipt } from './download.js';

let card, toggle, entries = new Map(), timer, pinned = false, hovered = false;
export function formatDownloadBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return '';
  if (bytes < 1024) return Math.floor(bytes) + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}
function stopTimer() { clearTimeout(timer); timer = null; }
function hide() {
  if (!card || card.hidden) return false;
  card.hidden = true;
  pinned = false;
  stopTimer();
  toggle?.setAttribute('aria-expanded', 'false');
  return true;
}
function scheduleDismiss() {
  stopTimer();
  if (card.hidden || pinned || hovered || card.contains(document.activeElement)) return;
  if (!entries.size || [...entries.values()].some(entry => entry.busy || entry.attention)) return;
  timer = setTimeout(hide, 4000);
  timer.unref?.();
}
function reveal(manual = false) {
  card.hidden = false;
  if (manual) pinned = true;
  toggle?.setAttribute('aria-expanded', 'true');
  stopTimer();
}
function mount() {
  if (card?.ownerDocument === document) return;
  stopTimer();
  entries = new Map(); pinned = hovered = false; toggle = null;
  card = document.createElement('section');
  card.className = 'lab-download-card';
  card.hidden = true;
  card.setAttribute('aria-label', 'Downloads / 下载');
  card.innerHTML = '<div class="lab-download-heading"><strong>下载</strong>'
    + '<button type="button" data-action="dismiss" aria-label="Hide download status">收起</button></div>'
    + '<div class="lab-download-list"></div>';
  document.body.appendChild(card);
  const dock = document.querySelector('.lab-appearance-dock');
  if (dock) {
    toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'lab-appearance-toggle';
    toggle.setAttribute('aria-label', 'Downloads / 下载');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.title = 'Downloads / 下载';
    toggle.innerHTML = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 7V5h6l2 2h10v13H3V7ZM12 10v7m-3-3 3 3 3-3"/></svg>';
    toggle.onclick = () => {
      document.defaultView.batonLabCloseAppearance?.();
      if (card.hidden) reveal(true); else hide();
    };
    dock.prepend(toggle);
  }
  document.defaultView.batonLabHideDownload = hide;
  document.defaultView.addEventListener('keydown', event => {
    if (event.key === 'Escape' && hide()) {
      event.preventDefault(); event.stopImmediatePropagation();
    }
  }, true);
  card.querySelector('[data-action="dismiss"]').onclick = hide;
  card.addEventListener('mouseenter', () => { hovered = true; stopTimer(); });
  card.addEventListener('mouseleave', () => { hovered = false; scheduleDismiss(); });
  card.addEventListener('focusin', stopTimer);
  card.addEventListener('focusout', () => queueMicrotask(scheduleDismiss));
}
function addEntry(id) {
  const node = document.createElement('article');
  node.className = 'lab-download-item';
  node.dataset.downloadId = id;
  node.innerHTML = '<strong class="lab-download-name"></strong>'
    + '<span class="lab-download-message" role="status" aria-live="polite"></span>'
    + '<progress aria-label="Download progress"></progress><div class="lab-download-actions">'
    + '<button type="button" data-action="open" hidden>打开文件</button>'
    + '<button type="button" data-action="folder" hidden>打开下载位置</button>'
    + '<button type="button" data-action="cancel" hidden>取消下载</button>'
    + '<button type="button" data-action="retry" hidden>重试下载</button></div>';
  const entry = { node };
  entries.set(id, entry);
  card.querySelector('.lab-download-list').prepend(node);
  for (const action of ['open', 'folder']) {
    node.querySelector(`[data-action="${action}"]`).onclick = async () => {
      try { await openDownloadReceipt(entry.receipt, action === 'folder'); }
      catch (error) {
        entry.attention = true;
        node.querySelector('.lab-download-message').textContent = String(error.message || error);
        reveal();
      }
    };
  }
  return entry;
}
export function showDownloadFeedback({ id = 'current', name, message, progress, result, busy = false,
  cancel, retry, attention = false, notify = false }) {
  mount();
  const isNew = !entries.has(id);
  const entry = entries.get(id) || addEntry(id);
  const node = entry.node;
  entry.busy = busy;
  entry.attention = attention;
  if (isNew || notify || entry.attention) reveal();
  if (name) node.querySelector('.lab-download-name').textContent = name;
  const bar = node.querySelector('progress');
  bar.hidden = !busy;
  if (progress) {
    const total = Number(progress.total);
    const received = Math.max(0, Number(progress.received) || 0);
    const known = Number.isFinite(total) && total > 0;
    bar.max = known ? total : 1;
    if (known) bar.value = received; else bar.removeAttribute('value');
    message = (progress.state === 'connecting' ? '正在连接下载… ' : progress.state === 'waiting' ? '系统正在等待传输… ' : '下载中… ')
      + (known ? `${Math.min(100, Math.floor(received / total * 100))}% · ` : '')
      + formatDownloadBytes(received) + (known ? ' / ' + formatDownloadBytes(total) : '');
  } else if (busy) bar.removeAttribute('value');
  if (message) node.querySelector('.lab-download-message').textContent = message;
  if (result) {
    entry.receipt = result;
    if (result.name) node.querySelector('.lab-download-name').textContent = result.name;
  } else if (name) entry.receipt = null;
  for (const action of ['open', 'folder']) node.querySelector(`[data-action="${action}"]`).hidden = busy || !entry.receipt?.id;
  const cancelButton = node.querySelector('[data-action="cancel"]');
  if (cancel !== undefined) cancelButton.onclick = cancel;
  cancelButton.hidden = !busy;
  cancelButton.disabled = !cancelButton.onclick;
  const retryButton = node.querySelector('[data-action="retry"]');
  retryButton.hidden = busy || !retry;
  retryButton.onclick = retry || null;
  const pending = [...entries.values()].filter(entry => entry.busy).length;
  toggle?.setAttribute('aria-label', pending ? `Downloads / 下载 · ${pending} 项进行中` : 'Downloads / 下载');
  toggle?.classList.toggle('is-downloading', pending > 0);
  scheduleDismiss();
}
