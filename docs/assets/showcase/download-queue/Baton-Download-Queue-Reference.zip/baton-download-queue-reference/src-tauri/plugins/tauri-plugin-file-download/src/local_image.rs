use crate::desktop::{PendingDownload, Progress};
use base64::{engine::general_purpose::STANDARD, Engine};
use std::{path::Path, time::Instant};

pub const MAX_BYTES: usize = 32 * 1024 * 1024;
const ENCODED_CHUNK: usize = 64 * 1024;
const INVALID: &str = "Invalid base64 image data URL";

fn parse(url: &str) -> Result<(&str, usize), String> {
    let comma = url.as_bytes().iter().take(64).position(|b| *b == b',').ok_or(INVALID)?;
    let mime = url[..comma].strip_prefix("data:")
        .and_then(|header| header.strip_suffix(";base64")).ok_or(INVALID)?;
    if !matches!(mime, "image/svg+xml" | "image/png" | "image/jpeg" | "image/gif" | "image/webp") {
        return Err("Unsupported local image MIME type".into());
    }
    let encoded = &url[comma + 1..];
    if encoded.len() > MAX_BYTES.div_ceil(3) * 4 {
        return Err("Local image exceeds 32 MiB".into());
    }
    if encoded.len() % 4 != 0 {
        return Err(INVALID.into());
    }
    let padding = encoded.as_bytes().iter().rev().take(3).take_while(|b| **b == b'=').count();
    if padding > 2 {
        return Err(INVALID.into());
    }
    let total = (encoded.len() / 4 * 3).checked_sub(padding).ok_or(INVALID)?;
    if total > MAX_BYTES {
        return Err("Local image exceeds 32 MiB".into());
    }
    Ok((encoded, total))
}

pub async fn save(
    url: &str,
    directory: &Path,
    name: &str,
    notify: impl FnMut(u64, Option<u64>),
) -> Result<PendingDownload, String> {
    let (encoded, size) = parse(url)?;
    let total = Some(size as u64);
    let mut pending = PendingDownload::create(directory, name, total).map_err(|e| e.to_string())?;
    let mut progress = Progress::new(notify, total, Instant::now());
    let mut buffer = [0u8; ENCODED_CHUNK / 4 * 3];
    let mut received = 0;
    for chunk in encoded.as_bytes().chunks(ENCODED_CHUNK) {
        // Yield within the operation's scope; cancellation drops the partial file.
        tokio::task::yield_now().await;
        let count = STANDARD.decode_slice(chunk, &mut buffer).map_err(|_| INVALID)?;
        received = pending.write_chunk(&buffer[..count], received, total).map_err(|e| e.to_string())?;
        progress.update(received, Instant::now(), false);
    }
    tokio::task::yield_now().await;
    pending.finish(received, total).map_err(|e| e.to_string())?;
    progress.update(received, Instant::now(), true);
    Ok(pending)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{desktop::Receipts, operations::{Operations, CANCELLED}};
    use std::{fs, path::PathBuf, sync::atomic::{AtomicUsize, Ordering}};

    struct Directory(PathBuf);
    impl Directory {
        fn new() -> Self {
            static NEXT: AtomicUsize = AtomicUsize::new(0);
            let path = std::env::temp_dir().join(format!("baton-local-image-{}-{}",
                std::process::id(), NEXT.fetch_add(1, Ordering::Relaxed)));
            fs::create_dir(&path).unwrap();
            Self(fs::canonicalize(path).unwrap())
        }
        fn empty(&self) -> bool { fs::read_dir(&self.0).unwrap().next().is_none() }
    }
    impl Drop for Directory {
        fn drop(&mut self) { let _ = fs::remove_dir_all(&self.0); }
    }
    fn url(mime: &str, bytes: &[u8]) -> String {
        format!("data:{mime};base64,{}", STANDARD.encode(bytes))
    }

    #[tokio::test]
    async fn exact_utf8_binary_empty_progress_and_receipts() {
        let dir = Directory::new();
        let mut receipts = Receipts::default();
        for (mime, bytes) in [
            ("image/svg+xml", "<svg><text>中文 &amp; café 🦀</text></svg>".as_bytes()),
            ("image/png", b"\x89PNG\r\n\x1a\n\0\xff".as_slice()),
            ("image/jpeg", b"\xff\xd8\xff\0\x01".as_slice()),
            ("image/gif", b"GIF89a\0\xff".as_slice()),
            ("image/webp", b"RIFF\0\xffWEBP".as_slice()),
            ("image/png", b"".as_slice()),
        ] {
            let ops = Operations::default();
            let mut op = ops.begin("view", Some("export")).unwrap();
            let mut progress = Vec::new();
            let pending = op.run(save(&url(mime, bytes), &dir.0, "../图表.png",
                |n, t| progress.push((n, t)))).await.unwrap();
            let path = pending.path().to_path_buf();
            assert_eq!(path.parent(), Some(dir.0.as_path()));
            assert_eq!(fs::read(&path).unwrap(), bytes);
            let id = op.complete(|| {
                let id = receipts.insert(&path).map_err(|e| e.to_string())?;
                pending.commit();
                Ok(id)
            }).unwrap();
            assert_eq!(receipts.resolve(&id).unwrap(), path);
            assert!(ops.cancel("view", "export").unwrap().is_none());
            assert!(path.exists());
            assert_eq!(progress.first(), Some(&(0, Some(bytes.len() as u64))));
            assert_eq!(progress.last(), Some(&(bytes.len() as u64, Some(bytes.len() as u64))));
        }
    }

    #[tokio::test]
    async fn strict_syntax_padding_mime_and_schemes_leave_no_files() {
        let dir = Directory::new();
        for bad in [
            "file:///etc/passwd", "https://example.com/a.png", "blob:abc",
            "data:text/html;base64,YQ==", "data:image/jpg;base64,YQ==",
            "data:image/png,YQ==", "data:image/png;charset=utf-8;base64,YQ==",
            "data:image/png;base64,YQ", "data:image/png;base64,YQ=",
            "data:image/png;base64,Y Q=", "data:image/png;base64,YQ==\n",
            "data:image/png;base64,YR==", "data:image/png;base64,YWJ=",
            "data:image/png;base64,====", "data:image/png;base64,AA-_",
            "data:image/png;base64,YQ==YQ==", "data:image/png;base64,中文",
        ] {
            assert!(save(bad, &dir.0, "bad.png", |_, _| {}).await.is_err(), "{bad}");
            assert!(dir.empty());
        }
        let embedded_padding = format!("data:image/png;base64,{}YQ==YQ==",
            "AAAA".repeat(ENCODED_CHUNK / 4 - 1));
        assert!(save(&embedded_padding, &dir.0, "bad.png", |_, _| {}).await.is_err());
        assert!(dir.empty());
    }

    #[tokio::test]
    async fn decoded_limit_is_inclusive_and_rejects_before_reserving() {
        let dir = Directory::new();
        let bytes = vec![255u8; MAX_BYTES];
        let pending = save(&url("image/png", &bytes), &dir.0, "max.png", |_, _| {}).await.unwrap();
        assert_eq!(fs::read(pending.path()).unwrap(), bytes);
        drop(pending);
        for size in [MAX_BYTES + 1, MAX_BYTES + 3] {
            assert!(save(&url("image/png", &vec![0; size]), &dir.0, "big.png", |_, _| {}).await
                .err().unwrap().contains("32 MiB"));
            assert!(dir.empty());
        }
    }

    #[tokio::test]
    async fn cancellation_during_writes_acknowledges_only_after_cleanup() {
        let dir = Directory::new();
        let ops = Operations::default();
        let mut op = ops.begin("view", Some("export")).unwrap();
        let path = dir.0.clone();
        let task = tokio::spawn(async move {
            op.run(save(&url("image/png", &vec![42; 1024 * 1024]),
                &path, "cancel.png", |_, _| {})).await
        });
        tokio::time::timeout(std::time::Duration::from_secs(5), async {
            loop {
                if fs::read_dir(&dir.0).unwrap().any(|e| e.unwrap().metadata().unwrap().len() > 0) { break; }
                tokio::task::yield_now().await;
            }
        }).await.unwrap();
        let mut done = ops.cancel("view", "export").unwrap().unwrap();
        done.wait_for(|done| *done).await.unwrap();
        assert!(dir.empty());
        assert!(matches!(task.await.unwrap(), Err(e) if e == CANCELLED));
    }

    #[tokio::test]
    async fn cancellation_before_receipt_and_malformed_late_chunk_remove_partial() {
        let dir = Directory::new();
        let ops = Operations::default();
        let mut op = ops.begin("view", Some("export")).unwrap();
        let pending = op.run(save(&url("image/png", b"bytes"), &dir.0, "x.png", |_, _| {})).await.unwrap();
        ops.cancel("view", "export").unwrap();
        let result = op.complete(|| { pending.commit(); Ok(()) });
        assert_eq!(result.unwrap_err(), CANCELLED);
        assert!(dir.empty());
        let bad = format!("data:image/png;base64,{}!!!!", "AAAA".repeat(ENCODED_CHUNK / 4));
        assert!(save(&bad, &dir.0, "bad.png", |_, _| {}).await.is_err());
        assert!(dir.empty());
    }
}
