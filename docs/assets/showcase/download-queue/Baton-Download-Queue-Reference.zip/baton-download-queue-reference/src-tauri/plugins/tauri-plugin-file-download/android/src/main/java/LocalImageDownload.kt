package com.batonai.download

import java.io.OutputStream
import java.util.Base64

internal data class ImageData(val url: String, val start: Int, val mime: String, val size: Int) {
  companion object {
    const val MAX_BYTES = 32 * 1024 * 1024
    const val CHUNK_CHARS = 64 * 1024
    private const val INVALID = "Invalid base64 image data URL"

    fun parse(url: String): ImageData {
      val comma = url.take(64).indexOf(',')
      require(comma >= 0) { INVALID }
      val header = url.substring(0, comma)
      require(header.startsWith("data:") && header.endsWith(";base64")) { INVALID }
      val mime = header.removePrefix("data:").removeSuffix(";base64")
      require(mime in setOf("image/svg+xml", "image/png", "image/jpeg", "image/gif", "image/webp")) {
        "Unsupported local image MIME type"
      }
      val length = url.length - comma - 1
      require(length <= ((MAX_BYTES + 2) / 3) * 4) { "Local image exceeds 32 MiB" }
      require(length % 4 == 0) { INVALID }
      var padding = 0
      while (padding < length && url[url.length - 1 - padding] == '=') {
        padding++
        require(padding <= 2) { INVALID }
      }
      val size = length / 4 * 3 - padding
      require(size in 0..MAX_BYTES) { "Local image exceeds 32 MiB" }
      return ImageData(url, comma + 1, mime, size)
    }
  }

  fun write(output: OutputStream, checkActive: () -> Unit, progress: (Long, Long) -> Unit) {
    var received = 0L
    progress(0, size.toLong())
    var offset = start
    while (offset < url.length) {
      checkActive()
      val end = minOf(offset + CHUNK_CHARS, url.length)
      val chunk = url.substring(offset, end)
      val bytes = try { Base64.getDecoder().decode(chunk) }
      catch (_: IllegalArgumentException) { error("Invalid base64 image data URL") }
      // Java's decoder accepts missing padding and nonzero pad bits; require canonical base64.
      require(Base64.getEncoder().encodeToString(bytes) == chunk &&
        (end == url.length || bytes.size == CHUNK_CHARS / 4 * 3)) {
        "Invalid base64 image data URL"
      }
      require(received + bytes.size <= size) { "Invalid base64 image data URL" }
      output.write(bytes)
      received += bytes.size
      progress(received, size.toLong())
      offset = end
    }
    checkActive()
    require(received == size.toLong()) { "Invalid base64 image data URL" }
    output.flush()
  }
}

internal interface PendingLocalImage {
  fun open(): OutputStream
  fun publish()
  fun delete()
}

internal class LocalImageOperation {
  private var cancelled = false
  private var committed = false

  @Synchronized fun cancel(): Boolean {
    if (committed) return false
    cancelled = true
    return true
  }

  @Synchronized fun isCancelled() = cancelled

  @Synchronized private fun checkActive() {
    check(!cancelled) { "Download cancelled" }
  }

  fun <T : PendingLocalImage> save(
    image: ImageData, create: () -> T, progress: (Long, Long) -> Unit
  ): T {
    checkActive()
    val pending = create()
    try {
      pending.open().use { image.write(it, ::checkActive, progress) }
      synchronized(this) {
        checkActive()
        pending.publish()
        committed = true
      }
      return pending
    } catch (error: Exception) {
      try { pending.delete() }
      catch (cleanup: Exception) {
        throw IllegalStateException("Local export failed; could not remove the partial Downloads entry", cleanup)
      }
      throw error
    }
  }
}

internal sealed class SavedDownload(val name: String, val mime: String) {
  abstract val id: String
  class Managed(val downloadId: Long, name: String, mime: String) : SavedDownload(name, mime) {
    override val id = downloadId.toString()
  }
  class Local(val uri: String, name: String, mime: String) : SavedDownload(name, mime) {
    override val id = "local:$uri"
  }
}
