use std::{
    collections::HashMap,
    fs::{self, File},
    io::{self, Write},
    path::{Path, PathBuf},
    process::Command,
    sync::Mutex,
    time::{Duration, Instant},
};
#[cfg(test)]
use std::io::Read;

#[cfg(test)]
#[path = "filename.rs"]
mod filename;
#[cfg(not(test))]
use crate::filename;

pub const MAX_BYTES: u64 = 512 * 1024 * 1024;
const PROGRESS_INTERVAL: Duration = Duration::from_millis(100);

/// A reserved destination is removed on every failure, including unwinding.
pub struct PendingDownload {
    path: PathBuf,
    file: Option<File>,
    committed: bool,
}

impl PendingDownload {
    pub fn create(directory: &Path, name: &str, total: Option<u64>) -> io::Result<Self> {
        if total.is_some_and(|total| total > MAX_BYTES) {
            return Err(io::Error::other("File exceeds 512 MB"));
        }
        fs::create_dir_all(directory)?;
        let directory = fs::canonicalize(directory)?;
        let (path, file) = filename::reserve_file(&directory, name)?;
        Ok(Self { path, file: Some(file), committed: false })
    }

    pub fn write_chunk(&mut self, bytes: &[u8], received: u64, total: Option<u64>) -> io::Result<u64> {
        let next = received.checked_add(bytes.len() as u64)
            .filter(|next| *next <= MAX_BYTES)
            .ok_or_else(|| io::Error::other("File exceeds 512 MB"))?;
        if total.is_some_and(|total| next > total) {
            return Err(io::Error::other("Received more bytes than Content-Length"));
        }
        self.file.as_mut().unwrap().write_all(bytes)?;
        Ok(next)
    }

    pub fn finish(&mut self, received: u64, total: Option<u64>) -> io::Result<()> {
        if total.is_some_and(|total| received != total) {
            return Err(io::Error::new(io::ErrorKind::UnexpectedEof,
                "Incomplete download: received bytes do not match Content-Length"));
        }
        self.file.as_mut().unwrap().sync_all()?;
        self.file.take();
        Ok(())
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn commit(mut self) {
        self.committed = true;
    }
}

impl Drop for PendingDownload {
    fn drop(&mut self) {
        self.file.take();
        if !self.committed {
            let _ = fs::remove_file(&self.path);
        }
    }
}

pub(crate) struct Progress<F> {
    notify: F,
    total: Option<u64>,
    last_report: Instant,
    last_received: u64,
}

impl<F: FnMut(u64, Option<u64>)> Progress<F> {
    pub(crate) fn new(mut notify: F, total: Option<u64>, now: Instant) -> Self {
        notify(0, total);
        Self {
            notify,
            total,
            last_report: now,
            last_received: 0,
        }
    }

    pub(crate) fn update(&mut self, received: u64, now: Instant, finished: bool) {
        if received != self.last_received
            && (finished || now.duration_since(self.last_report) >= PROGRESS_INTERVAL)
        {
            (self.notify)(received, self.total);
            self.last_received = received;
            self.last_report = now;
        }
    }
}

#[cfg(test)]
fn copy_stream(
    reader: &mut impl Read,
    writer: &mut impl Write,
    total: Option<u64>,
    limit: u64,
    mut progress: impl FnMut(u64),
) -> io::Result<u64> {
    let mut buffer = [0; 64 * 1024];
    let mut received = 0;
    loop {
        let count = match reader.read(&mut buffer) {
            Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
            result => result?,
        };
        if count == 0 {
            break;
        }
        let next = received + count as u64;
        if next > limit {
            return Err(io::Error::other("File exceeds 512 MB"));
        }
        if total.is_some_and(|total| next > total) {
            return Err(io::Error::other("Received more bytes than Content-Length"));
        }
        writer.write_all(&buffer[..count])?;
        received = next;
        progress(received);
    }
    if total.is_some_and(|total| received != total) {
        return Err(io::Error::new(
            io::ErrorKind::UnexpectedEof,
            "Incomplete download: received bytes do not match Content-Length",
        ));
    }
    writer.flush()?;
    Ok(received)
}

#[cfg(test)]
pub fn save_stream(
    reader: &mut impl Read,
    directory: &Path,
    name: &str,
    total: Option<u64>,
    notify: impl FnMut(u64, Option<u64>),
) -> io::Result<PendingDownload> {
    save_stream_with_limit(reader, directory, name, total, MAX_BYTES, notify)
}

#[cfg(test)]
fn save_stream_with_limit(
    reader: &mut impl Read,
    directory: &Path,
    name: &str,
    total: Option<u64>,
    limit: u64,
    notify: impl FnMut(u64, Option<u64>),
) -> io::Result<PendingDownload> {
    if total.is_some_and(|total| total > limit) {
        return Err(io::Error::other("File exceeds 512 MB"));
    }
    let mut pending = PendingDownload::create(directory, name, total)?;
    let mut progress = Progress::new(notify, total, Instant::now());
    let file = pending.file.as_mut().unwrap();
    let received = copy_stream(reader, file, total, limit, |received| {
        progress.update(received, Instant::now(), false);
    })?;
    pending.finish(received, total)?;
    progress.update(received, Instant::now(), true);
    Ok(pending)
}

#[derive(Default)]
pub struct Receipts {
    next_id: u64,
    paths: HashMap<String, PathBuf>,
}

impl Receipts {
    pub fn insert(&mut self, path: &Path) -> io::Result<String> {
        validate_path(path)?;
        self.next_id = self
            .next_id
            .checked_add(1)
            .ok_or_else(|| io::Error::other("Download receipt IDs exhausted"))?;
        let id = format!("download-{}", self.next_id);
        self.paths.insert(id.clone(), path.to_path_buf());
        Ok(id)
    }

    pub fn resolve(&self, id: &str) -> io::Result<PathBuf> {
        let path = self
            .paths
            .get(id)
            .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "Unknown download receipt"))?;
        validate_path(path)?;
        Ok(path.clone())
    }
}

fn validate_path(path: &Path) -> io::Result<()> {
    if !path.is_absolute()
        || !fs::symlink_metadata(path)?.file_type().is_file()
        || fs::canonicalize(path)? != path
    {
        return Err(io::Error::other("Saved download is no longer a regular file at its recorded path"));
    }
    Ok(())
}

fn open_command(path: &Path, reveal: bool) -> io::Result<Command> {
    #[cfg(target_os = "macos")]
    {
        let mut command = Command::new("/usr/bin/open");
        if reveal {
            command.arg("-R");
        }
        command.arg(path);
        Ok(command)
    }
    #[cfg(target_os = "linux")]
    {
        let mut command = Command::new("xdg-open");
        // xdg-open has no portable file-selection API; reveal opens its folder.
        command.arg(if reveal {
            path.parent().ok_or_else(|| io::Error::other("Missing download folder"))?
        } else {
            path
        });
        Ok(command)
    }
    #[cfg(not(any(target_os = "macos", target_os = "linux")))]
    {
        let _ = (path, reveal);
        Err(io::Error::new(io::ErrorKind::Unsupported, "Opening downloads is unsupported on this platform"))
    }
}

pub fn open_receipt(receipts: &Mutex<Receipts>, id: &str, reveal: bool) -> io::Result<()> {
    let path = receipts
        .lock()
        .map_err(|_| io::Error::other("Download receipts unavailable"))?
        .resolve(id)?;
    let output = open_command(&path, reveal)?.output()?;
    if !output.status.success() {
        return Err(io::Error::other(format!(
            "System file opener failed ({})",
            output.status
        )));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};

    struct TempDir(PathBuf);
    impl TempDir {
        fn new() -> Self {
            static NEXT: AtomicU64 = AtomicU64::new(0);
            let path = std::env::temp_dir().join(format!(
                "baton-download-test-{}-{}",
                std::process::id(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            ));
            fs::create_dir(&path).unwrap();
            Self(fs::canonicalize(path).unwrap())
        }
        fn empty(&self) -> bool {
            fs::read_dir(&self.0).unwrap().next().is_none()
        }
    }
    impl Drop for TempDir {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }

    #[test]
    fn saves_exact_bytes_with_known_unknown_and_empty_lengths() {
        for (bytes, total) in [
            (b"hello".as_slice(), Some(5)),
            (b"hello".as_slice(), None),
            (b"".as_slice(), Some(0)),
            (b"".as_slice(), None),
        ] {
            let dir = TempDir::new();
            let mut events = Vec::new();
            let pending = save_stream(&mut &*bytes, &dir.0, "data.txt", total, |n, t| {
                events.push((n, t));
            }).unwrap();
            assert_eq!(fs::read(pending.path()).unwrap(), bytes);
            assert_eq!(events.first(), Some(&(0, total)));
            assert_eq!(events.last(), Some(&(bytes.len() as u64, total)));
            let path = pending.path().to_path_buf();
            pending.commit();
            assert!(path.exists());
        }
    }

    #[test]
    fn mismatched_lengths_and_limits_leave_no_partial_file() {
        for (bytes, total, limit) in [
            (b"abc".as_slice(), Some(4), 10),
            (b"abc".as_slice(), Some(2), 10),
            (b"abc".as_slice(), None, 2),
            (b"abc".as_slice(), Some(3), 2),
            (b"".as_slice(), Some(1), 10),
        ] {
            let dir = TempDir::new();
            assert!(save_stream_with_limit(&mut &*bytes, &dir.0, "data", total, limit, |_, _| {}).is_err());
            assert!(dir.empty());
        }
        let dir = TempDir::new();
        assert!(save_stream(&mut io::empty(), &dir.0, "data", Some(MAX_BYTES + 1), |_, _| {}).is_err());
        assert!(dir.empty());
    }

    #[test]
    fn exact_limit_is_accepted() {
        let dir = TempDir::new();
        for total in [Some(3), None] {
            let pending = save_stream_with_limit(&mut &b"abc"[..], &dir.0, "data", total, 3, |_, _| {}).unwrap();
            assert_eq!(fs::read(pending.path()).unwrap(), b"abc");
        }
        assert!(dir.empty());
    }

    #[test]
    fn async_chunk_writer_enforces_limits_and_length_and_cleans_up() {
        let dir = TempDir::new();
        {
            let mut pending = PendingDownload::create(&dir.0, "data", None).unwrap();
            assert!(pending.write_chunk(b"x", MAX_BYTES, None).is_err());
            assert!(pending.write_chunk(b"x", u64::MAX, None).is_err());
            assert!(pending.write_chunk(b"abc", 0, Some(2)).is_err());
            assert_eq!(pending.write_chunk(b"abc", 0, Some(4)).unwrap(), 3);
            assert!(pending.finish(3, Some(4)).is_err());
        }
        assert!(dir.empty());
    }

    #[test]
    fn reader_failure_and_abandoned_receipt_clean_up() {
        struct BrokenReader(bool);
        impl Read for BrokenReader {
            fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
                if self.0 { return Err(io::Error::other("connection lost")); }
                self.0 = true;
                buffer[0] = 42;
                Ok(1)
            }
        }
        let dir = TempDir::new();
        assert!(save_stream(&mut BrokenReader(false), &dir.0, "data", None, |_, _| {}).is_err());
        assert!(dir.empty());
        let pending = save_stream(&mut &b"abc"[..], &dir.0, "data", None, |_, _| {}).unwrap();
        drop(pending);
        assert!(dir.empty());
    }

    #[test]
    fn write_and_flush_errors_propagate() {
        struct BrokenWriter(bool);
        impl Write for BrokenWriter {
            fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
                if self.0 { Err(io::Error::other("disk full")) } else { Ok(bytes.len()) }
            }
            fn flush(&mut self) -> io::Result<()> { Err(io::Error::other("flush failed")) }
        }
        for fail_write in [true, false] {
            assert!(copy_stream(&mut &b"abc"[..], &mut BrokenWriter(fail_write), None, 3, |_| {}).is_err());
        }
    }

    #[test]
    fn fragmented_reads_interruptions_and_short_writes_preserve_true_bytes() {
        struct FragmentedReader { remaining: usize, interrupted: bool }
        impl Read for FragmentedReader {
            fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
                self.interrupted = !self.interrupted;
                if self.interrupted {
                    return Err(io::ErrorKind::Interrupted.into());
                }
                let count = self.remaining.min(997).min(buffer.len());
                buffer[..count].fill(42);
                self.remaining -= count;
                Ok(count)
            }
        }
        struct ShortWriter(Vec<u8>);
        impl Write for ShortWriter {
            fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
                let count = bytes.len().min(7);
                self.0.extend_from_slice(&bytes[..count]);
                Ok(count)
            }
            fn flush(&mut self) -> io::Result<()> { Ok(()) }
        }
        let mut reader = FragmentedReader { remaining: 150_001, interrupted: false };
        let mut writer = ShortWriter(Vec::new());
        let mut counts = Vec::new();
        assert_eq!(copy_stream(&mut reader, &mut writer, Some(150_001), MAX_BYTES, |n| counts.push(n)).unwrap(), 150_001);
        assert_eq!(writer.0, vec![42; 150_001]);
        assert!(counts.windows(2).all(|pair| pair[0] < pair[1]));
        assert_eq!(counts.last(), Some(&150_001));
    }

    #[test]
    fn progress_is_throttled_and_final_count_is_never_lost() {
        let mut events = Vec::new();
        let start = Instant::now();
        let mut progress = Progress::new(|n, total| events.push((n, total)), None, start);
        progress.update(5, start + Duration::from_millis(10), false);
        progress.update(10, start + Duration::from_millis(100), false);
        progress.update(15, start + Duration::from_millis(110), false);
        progress.update(20, start + Duration::from_millis(120), true);
        progress.update(20, start + Duration::from_millis(121), true);
        assert_eq!(events, [(0, None), (10, None), (20, None)]);
    }

    #[test]
    fn receipts_are_unique_and_reject_unknown_missing_and_symlink_paths() {
        let dir = TempDir::new();
        let mut receipts = Receipts::default();
        let first = save_stream(&mut &b"a"[..], &dir.0, "../file.txt", None, |_, _| {}).unwrap();
        let second = save_stream(&mut &b"b"[..], &dir.0, "../file.txt", None, |_, _| {}).unwrap();
        assert_eq!(first.path().parent(), Some(dir.0.as_path()));
        assert_ne!(first.path(), second.path());
        let first_id = receipts.insert(first.path()).unwrap();
        let second_id = receipts.insert(second.path()).unwrap();
        assert_ne!(first_id, second_id);
        assert_eq!(receipts.resolve(&first_id).unwrap(), first.path());
        assert!(receipts.resolve("/etc/passwd").is_err());
        assert!(receipts.resolve("download-999").is_err());
        let first_path = first.path().to_path_buf();
        first.commit();
        fs::remove_file(&first_path).unwrap();
        assert!(receipts.resolve(&first_id).is_err());
        #[cfg(unix)]
        {
            std::os::unix::fs::symlink(second.path(), &first_path).unwrap();
            assert!(receipts.resolve(&first_id).is_err());
            assert!(receipts.insert(&first_path).is_err());
        }
    }

    #[test]
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    fn opener_uses_literal_paths_without_a_shell() {
        let path = Path::new("/tmp/a folder/$(touch should-not-exist).txt");
        let open = open_command(path, false).unwrap();
        let reveal = open_command(path, true).unwrap();
        assert_eq!(open.get_args().collect::<Vec<_>>(), [path.as_os_str()]);
        #[cfg(target_os = "macos")]
        {
            assert_eq!(open.get_program(), "/usr/bin/open");
            assert_eq!(reveal.get_args().collect::<Vec<_>>(), [std::ffi::OsStr::new("-R"), path.as_os_str()]);
        }
        #[cfg(target_os = "linux")]
        {
            assert_eq!(open.get_program(), "xdg-open");
            assert_eq!(reveal.get_args().collect::<Vec<_>>(), [path.parent().unwrap().as_os_str()]);
        }
    }
}
