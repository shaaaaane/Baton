plugins { id("com.android.library"); id("org.jetbrains.kotlin.android") }
layout.buildDirectory.set(layout.projectDirectory.dir(".build"))
android {
  namespace = "com.batonai.download"
  compileSdk = 36
  defaultConfig { minSdk = 24 }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_1_8; targetCompatibility = JavaVersion.VERSION_1_8 }
  kotlinOptions { jvmTarget = "1.8" }
  sourceSets.getByName("test").java.srcDir("../../../../test/native/file-download-android")
}
dependencies {
  implementation(project(":tauri-android"))
  testImplementation("junit:junit:4.13.2")
}
