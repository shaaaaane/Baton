import { createDownloadQueue } from '../web/js/project/download-queue.js';
import { downloadFile } from '../web/js/project/download.js';
import { showDownloadFeedback } from '../web/js/project/download-feedback.js';

const transfers = new Map(), journal = [];
let nextCallback = 0, batch = 0;
const callbacks = new Map();
const log = value => { journal.push(value); document.querySelector('.demo-log').textContent = journal.slice(-6).join('\n'); };
window.__TAURI_INTERNALS__ = {
  transformCallback(fn) { const id = ++nextCallback; callbacks.set(id, fn); return id; },
  unregisterCallback(id) { callbacks.delete(id); },
  invoke(command, args) {
    if (command.endsWith('|download')) return new Promise((resolve, reject) => {
      const transfer = { ...args, resolve, reject, index: 0, received: 0, total: 5 * 1024 * 1024 };
      transfers.set(args.requestId, transfer); log('开始：' + args.name);
    });
    if (command.endsWith('|cancel')) {
      const transfer = transfers.get(args.requestId);
      if (transfer) { transfers.delete(args.requestId); transfer.reject(new Error('Download cancelled')); log('模拟器确认取消：' + transfer.name); }
      return Promise.resolve();
    }
    if (command.endsWith('|open_download') || command.endsWith('|reveal_download')) {
      log('模拟系统操作：' + command.split('|')[1] + ' / ' + args.id); return Promise.resolve();
    }
    return Promise.reject(new Error('Unexpected demo command'));
  },
};
const queue = createDownloadQueue(async (target, signal, update) => {
  update({ state: 'transferring' });
  return downloadFile(target, progress => update({ progress }), { signal });
}, (item, event) => {
  const busy = ['queued', 'preparing', 'transferring', 'cancelling'].includes(item.state);
  const retryable = ['error', 'cancelled', 'ready'].includes(item.state);
  const message = { queued:'等待下载…',preparing:'正在准备文件…',transferring:'正在连接下载…',cancelling:'正在取消下载…',cancelled:'已取消下载。',error:'下载失败：'+(item.error?.message||''),success:'下载完成 · Downloads' }[item.state];
  showDownloadFeedback({ id:item.id,name:item.target.name,message,busy,result:item.result,
    progress:item.state==='transferring'?item.progress:null,
    cancel:item.state==='cancelling'?null:()=>queue.cancel(item.id),retry:retryable?()=>queue.retry(item.id):null,
    attention:item.state==='error',notify:event==='added' });
});
const active = () => transfers.values().next().value;
const controls = {
  enqueue() { batch++; return ['课程讲义.pdf','参考资料.zip','工作流程.svg'].map(name => queue.enqueue({name,url:'https://download.example/'+encodeURIComponent(name),device:'demo-device',projectHash:'demo-project',path:name,batch})); },
  progress(received, total = 5 * 1024 * 1024) {
    const transfer=active();if(!transfer)return;transfer.received=received??Math.min(total,transfer.received+Math.round(total*.15));
    callbacks.get(transfer.onProgress.id)?.({index:transfer.index++,message:{received:transfer.received,total}});
  },
  complete() { const transfer=active();if(!transfer)return;transfers.delete(transfer.requestId);transfer.resolve({status:'saved',id:'demo-'+transfer.requestId,name:transfer.name});log('模拟完成：'+transfer.name); },
  fail() { const transfer=active();if(!transfer)return;transfers.delete(transfer.requestId);transfer.reject(new Error('连接中断，请重试'));log('模拟失败：'+transfer.name); },
  queue, transfers, journal,
};
for (const name of ['enqueue','progress','complete','fail']) document.getElementById(name).onclick=()=>controls[name]();
window.downloadQueueDemo=controls;

const layout = () => document.documentElement.style.setProperty("--lab-toolbar-bottom", (document.querySelector(".demo-actions").getBoundingClientRect().bottom + 12) + "px");
window.addEventListener("resize", layout); layout();
