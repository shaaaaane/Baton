# Existing file-viewer integration

Verbatim excerpt from `web/js/project/file-viewer.js`. This is reference context, not a standalone module.

```js
function uploadedKey(target) {
  if (!target.keyPromise) {
    target.keyPromise = target.key ? Promise.resolve(target.key) : requestProjectFiles('download', {
      projectHash: target.projectHash, device: target.device, path: target.path,
    }, { timeout: 5 * 60_000 }).then(result => (target.key = result.key));
    target.keyPromise.catch(() => { target.keyPromise = null; });
  }
  return target.keyPromise;
}

// Identical content shares one stored file, so the name it was opened under wins over the stored one.
function attachmentUrl(key, name) {
  return '/api/bridge/file-url/' + key + (name ? '?name=' + encodeURIComponent(name) : '');
}

async function showUploadedProjectFile(target) {
  const token = ++_fileRequestToken;
  try {
    const key = await uploadedKey(target);
    if (token === _fileRequestToken) showAttachment(key);
  } catch (error) {
    if (token === _fileRequestToken) setBody('<div class="file-error">' + esc(String(error.message || error)) + '</div>');
  }
}

function updateDownloadButtons() {
  document.querySelectorAll('#file-download-btn, #fileOverlay .file-download-action').forEach(button => {
    button.disabled = !_downloadTarget;
    button.classList.remove('is-downloading');
    button.removeAttribute('aria-busy');
    button.querySelector('.file-download-spinner')?.remove();
  });
}

async function prepareViewedDownload(target, signal, onStage = () => {}) {
  onStage('正在等待设备准备文件…');
  const key = await runDownloadStage(() => uploadedKey(target),
    { signal, timeout: 5 * 60_000, message: '设备准备文件超过 5 分钟，请重试。' });
  signal?.throwIfAborted();
  onStage('正在获取下载地址…');
  return runDownloadStage(stageSignal => window.api(attachmentUrl(key, target.name), null, { signal: stageSignal }),
    { signal, message: '获取下载地址超过 30 秒，请重试。' });
}

const downloadQueue = createDownloadQueue(async (target, signal, update) => {
  signal.throwIfAborted();
  if (target.sharedFile) return shareDownloadedFile(target);
  const file = target.prepareLocalFile
    ? await runDownloadStage(target.prepareLocalFile, { signal, timeout: 30000, message: '准备导出超时，请重试。' })
    : target.localFile || await prepareViewedDownload(target, signal, message => update({ message }));
  signal.throwIfAborted();
  update({ state: 'transferring', message: '正在连接下载…' });
  const progress = progress => update({ progress });
  if (browserCanShare() && file.size <= BROWSER_SHARE_MAX_BYTES) {
    try {
      target.sharedFile = await runDownloadStage(stageSignal => prepareSharedFile(file, progress, { signal: stageSignal }),
        { signal, timeout: 5 * 60_000, message: '文件接收超时，请重试下载。' });
    } catch (error) {
      if (error.name !== 'NotSupportedError') throw error;
    }
  }
  signal.throwIfAborted();
  return target.sharedFile ? shareDownloadedFile(target) : downloadFile(file, progress, { signal });
}, (item, event) => {
  const busy = ['queued', 'preparing', 'transferring', 'cancelling'].includes(item.state);
  const retryable = ['error', 'cancelled', 'ready'].includes(item.state);
  const message = {
    queued: '等待下载…', preparing: item.message || '正在准备文件…',
    transferring: item.message || '下载中…', cancelling: '正在取消下载…',
    cancelled: '已取消下载。', error: '下载失败：' + String(item.error?.message || ''),
    ready: '文件已就绪，点击重试打开分享。',
    success: {
      saved: '下载完成 · Downloads', started: '已交给浏览器下载，请在浏览器下载列表查看。',
      shared: '已分享', share_opened: '下载完成', queued: '已加入系统下载列表',
    }[item.result?.status] || '下载已启动',
  }[item.state];
  showDownloadFeedback({ id: item.id, name: item.target.name || item.target.path.split('/').pop(),
    message, busy, result: item.result, progress: item.state === 'transferring' ? item.progress : null,
    cancel: item.state === 'cancelling' ? null : () => downloadQueue.cancel(item.id),
    retry: retryable ? () => downloadQueue.retry(item.id) : null,
    attention: item.state === 'error' || item.state === 'ready', notify: event === 'added',
  });
  if (_downloadTarget && ['device', 'projectHash', 'path'].every(key => _downloadTarget[key] === item.target[key])) {
    if (item.target.sharedFile) _downloadTarget.sharedFile = item.target.sharedFile;
    downloadStatus(message);
  }
  if (event === 'finish' && item.state === 'success') {
    // The receipt is enough after saving; do not retain large image snapshots in history.
    delete item.target.localFile;
    delete item.target.prepareLocalFile;
  }
});

function downloadViewedFile() {
  if (!_downloadTarget) return;
  return downloadProjectFile(_downloadTarget);
}

export function downloadProjectFile(target) {
  return downloadQueue.enqueue(target).done;
}

// Native window owners can use the same guard before closing a WebView.
export function pendingFileDownloads() { return downloadQueue.pending; }
export function cancelFileDownloads() { return downloadQueue.cancelAll(); }
window.addEventListener('beforeunload', event => {
  if (!downloadQueue.pending) return;
  event.preventDefault();
  event.returnValue = '';
});

async function shareDownloadedFile(target) {
  try {
    await navigator.share({ files: [target.sharedFile] });
    return { status: 'shared' };
  } catch (error) {
    if (error.name === 'AbortError') return { status: 'cancelled' };
    if (error.name === 'NotAllowedError') return { status: 'ready' };
    throw error;
  }
}
```
