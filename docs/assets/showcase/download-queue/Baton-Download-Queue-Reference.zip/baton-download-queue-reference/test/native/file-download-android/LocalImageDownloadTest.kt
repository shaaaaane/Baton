package com.batonai.download

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.Base64
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import org.junit.Assert.*
import org.junit.Test

class LocalImageDownloadTest {
  private fun url(bytes: ByteArray, mime: String = "image/png") =
    "data:$mime;base64," + Base64.getEncoder().encodeToString(bytes)

  private class Entry(val fail: String? = null) : PendingLocalImage {
    val bytes = ByteArrayOutputStream()
    var closed = false
    var deleted = false
    var published = false
    override fun open(): OutputStream {
      if (fail == "open") throw IOException("open")
      return object : OutputStream() {
        override fun write(value: Int) { bytes.write(value) }
        override fun write(buffer: ByteArray) {
          if (fail == "write") throw IOException("write")
          bytes.write(buffer)
        }
        override fun flush() { if (fail == "flush") throw IOException("flush") }
        override fun close() {
          closed = true
          if (fail == "close") throw IOException("close")
        }
      }
    }
    override fun publish() {
      check(closed)
      if (fail == "publish") throw IOException("publish")
      published = true
    }
    override fun delete() {
      if (fail == "delete") throw IOException("delete")
      deleted = true
      bytes.reset()
    }
  }

  @Test fun preservesExactUtf8BinaryAndEmptyBytesWithProgress() {
    for ((mime, bytes) in listOf(
      "image/svg+xml" to "<svg><text>中文 &amp; café 🦀</text></svg>".toByteArray(),
      "image/png" to byteArrayOf(0x89.toByte(), 0x50, 0, 0xff.toByte()),
      "image/jpeg" to byteArrayOf(0xff.toByte(), 0xd8.toByte(), 0, 0xff.toByte()),
      "image/gif" to "GIF89a".toByteArray(),
      "image/webp" to "RIFF\u0000WEBP".toByteArray(),
      "image/png" to byteArrayOf()
    )) {
      val image = ImageData.parse(url(bytes, mime))
      val entry = Entry()
      val operation = LocalImageOperation()
      val progress = mutableListOf<Pair<Long, Long>>()
      assertSame(entry, operation.save(image, { entry }) { n, t -> progress.add(n to t) })
      assertArrayEquals(bytes, entry.bytes.toByteArray())
      assertEquals(mime, image.mime)
      assertEquals(0L to bytes.size.toLong(), progress.first())
      assertEquals(bytes.size.toLong() to bytes.size.toLong(), progress.last())
      assertTrue(entry.closed && entry.published && !entry.deleted)
      assertFalse(operation.cancel())
    }
  }

  @Test fun rejectsMalformedAndDisallowedInputsAndRemovesPartialEntries() {
    val invalid = listOf(
      "file:///private/image.png", "https://example.com/a.png", "blob:abc",
      "data:text/html;base64,YQ==", "data:image/jpg;base64,YQ==",
      "data:image/png,YQ==", "data:image/png;charset=utf-8;base64,YQ==",
      "data:image/png;base64,YQ", "data:image/png;base64,YQ=",
      "data:image/png;base64,Y Q=", "data:image/png;base64,YQ==\n",
      "data:image/png;base64,YR==", "data:image/png;base64,YWJ=",
      "data:image/png;base64,====", "data:image/png;base64,AA-_",
      "data:image/png;base64,YQ==YQ==", "data:image/png;base64,中文",
      "data:image/png;base64," + "AAAA".repeat(ImageData.CHUNK_CHARS / 4) + "!!!!",
      "data:image/png;base64," + "AAAA".repeat(ImageData.CHUNK_CHARS / 4 - 1) + "YQ==YQ=="
    )
    for (bad in invalid) {
      var entry: Entry? = null
      assertThrows(bad, Exception::class.java) {
        LocalImageOperation().save(ImageData.parse(bad), { Entry().also { entry = it } }) { _, _ -> }
      }
      entry?.let { assertTrue(bad, it.deleted && !it.published && it.bytes.size() == 0) }
    }
  }

  @Test fun acceptsExact32MiBLimitAndRejectsOversizeBeforeCreating() {
    val bytes = ByteArray(ImageData.MAX_BYTES) { 0xff.toByte() }
    val image = ImageData.parse(url(bytes))
    var received = 0
    val output = object : OutputStream() {
      override fun write(value: Int) { fail("expected chunked writes") }
      override fun write(chunk: ByteArray) {
        assertTrue(chunk.size <= ImageData.CHUNK_CHARS / 4 * 3)
        assertTrue(chunk.all { it == 0xff.toByte() })
        received += chunk.size
      }
    }
    image.write(output, {}, { _, _ -> })
    assertEquals(ImageData.MAX_BYTES, received)
    for (size in listOf(ImageData.MAX_BYTES + 1, ImageData.MAX_BYTES + 3)) {
      val error = assertThrows(IllegalArgumentException::class.java) { ImageData.parse(url(ByteArray(size))) }
      assertTrue(error.message!!.contains("32 MiB"))
    }
  }

  @Test fun cleansUpOnOpenWriteFlushCloseAndPublishFailures() {
    for (failure in listOf("open", "write", "flush", "close", "publish")) {
      val entry = Entry(failure)
      assertThrows(IOException::class.java) {
        LocalImageOperation().save(ImageData.parse(url(byteArrayOf(0, -1))), { entry }) { _, _ -> }
      }
      assertTrue(failure, entry.deleted && !entry.published && entry.bytes.size() == 0)
      if (failure != "open") assertTrue(entry.closed)
    }
  }

  @Test fun cancellationBeforeStartNeverCreatesAnEntry() {
    val operation = LocalImageOperation()
    assertTrue(operation.cancel())
    val error = assertThrows(IllegalStateException::class.java) {
      operation.save(ImageData.parse(url(byteArrayOf(1))), { error("must not create") }) { _, _ -> }
    }
    assertEquals("Download cancelled", error.message)
  }

  @Test fun cancellationDuringWriteAndBeforePublishCleansBeforeReturning() {
    for (atEnd in listOf(false, true)) {
      val operation = LocalImageOperation()
      val entry = Entry()
      val total = 200_000
      val error = assertThrows(IllegalStateException::class.java) {
        operation.save(ImageData.parse(url(ByteArray(total))), { entry }) { n, _ ->
          if ((atEnd && n == total.toLong()) || (!atEnd && n > 0)) operation.cancel()
        }
      }
      assertEquals("Download cancelled", error.message)
      assertTrue(entry.closed && entry.deleted && !entry.published)
      assertEquals(0, entry.bytes.size())
    }
  }

  @Test fun cancellationCannotReturnSuccessBeforeBlockedWriterClosesAndDeletes() {
    val operation = LocalImageOperation()
    val writing = CountDownLatch(1)
    val release = CountDownLatch(1)
    val finished = CountDownLatch(1)
    val failure = AtomicReference<Throwable>()
    val entry = Entry()
    val thread = Thread {
      try {
        operation.save(ImageData.parse(url(ByteArray(200_000))), { entry }) { n, _ ->
          if (n > 0) {
            writing.countDown()
            check(release.await(5, TimeUnit.SECONDS))
          }
        }
      } catch (error: Throwable) { failure.set(error) }
      finally { finished.countDown() }
    }
    thread.start()
    assertTrue(writing.await(5, TimeUnit.SECONDS))
    assertTrue(operation.cancel())
    assertFalse(finished.await(20, TimeUnit.MILLISECONDS))
    release.countDown()
    assertTrue(finished.await(5, TimeUnit.SECONDS))
    thread.join()
    assertEquals("Download cancelled", failure.get().message)
    assertTrue(entry.closed && entry.deleted && !entry.published)
  }

  @Test fun cleanupFailureIsReportedRatherThanClaimingSuccessfulCancellation() {
    val operation = LocalImageOperation()
    val error = assertThrows(IllegalStateException::class.java) {
      operation.save(ImageData.parse(url(byteArrayOf(1))), { Entry("delete") }) { _, _ -> operation.cancel() }
    }
    assertTrue(error.message!!.contains("could not remove"))
  }

  @Test fun numericDownloadManagerAndLocalUriReceiptsCoexist() {
    val remote = SavedDownload.Managed(123L, "remote.png", "image/png")
    val local = SavedDownload.Local("content://media/external/downloads/123", "图表.svg", "image/svg+xml")
    val receipts = mapOf(remote.id to remote, local.id to local)
    assertEquals("123", remote.id)
    assertEquals(123L, (receipts["123"] as SavedDownload.Managed).downloadId)
    assertEquals(local.uri, (receipts[local.id] as SavedDownload.Local).uri)
    assertEquals("image/svg+xml", receipts[local.id]!!.mime)
    assertNull(receipts[local.uri])
    assertNull(receipts["file:///etc/passwd"])
  }
}
