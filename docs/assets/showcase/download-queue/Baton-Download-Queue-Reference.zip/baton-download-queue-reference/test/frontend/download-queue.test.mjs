import test from 'node:test';
import assert from 'node:assert/strict';
import { createDownloadQueue } from '../../web/js/project/download-queue.js';
const tick = () => new Promise(resolve => setImmediate(resolve));
const deferred = () => { let resolve, reject; const promise = new Promise((a, b) => { resolve = a; reject = b; }); return { promise, resolve, reject }; };

test('queue accepts more work while active, binds each descriptor, and transfers serially', async () => {
  const jobs = [];
  const queue = createDownloadQueue((target, signal, update) => {
    const job = { ...deferred(), target, signal, update }; jobs.push(job); return job.promise;
  });
  const target = { device: 'Mac', projectHash: 'A', path: '/A/report.pdf', name: 'report.pdf' };
  const first = queue.enqueue(target);
  target.device = 'Android'; target.projectHash = 'B'; target.path = '/B/other.pdf';
  const second = queue.enqueue(target);
  assert.equal(jobs.length, 1);
  assert.equal(queue.pending, 2);
  assert.deepEqual(jobs[0].target, { device: 'Mac', projectHash: 'A', path: '/A/report.pdf', name: 'report.pdf' });
  jobs[0].resolve({ status: 'saved', id: 'A' });
  await first.done;
  assert.equal(jobs.length, 2);
  assert.equal(jobs[1].target.device, 'Android');
  jobs[1].resolve({ status: 'saved', id: 'B' });
  await second.done;
  assert.equal(queue.pending, 0);
});

test('queued cancellation does not start a transfer or cancel its active neighbour', async () => {
  const work = deferred(); let calls = 0;
  const queue = createDownloadQueue(() => { calls++; return work.promise; });
  const a = queue.enqueue({ path: 'a' }), b = queue.enqueue({ path: 'b' });
  queue.cancel(b.id);
  assert.equal((await b.done).state, 'cancelled');
  assert.equal(queue.pending, 1);
  work.resolve({ status: 'saved' }); await a.done;
  assert.equal(calls, 1);
});

test('active cancellation waits for the executor to settle before starting the next transfer', async () => {
  const work = deferred(), calls = [], changes = [];
  const queue = createDownloadQueue((target, signal, update) => {
    calls.push({ target, signal, update });
    return calls.length === 1 ? work.promise : Promise.resolve({ status: 'saved' });
  }, (item, event) => changes.push([item.id, item.state, event]));
  const a = queue.enqueue({ path: 'a' }), b = queue.enqueue({ path: 'b' });
  queue.cancel(a.id);
  assert.equal(calls[0].signal.aborted, true);
  calls[0].update({ state: 'transferring', progress: { received: 10 } });
  await tick();
  assert.equal(a.state, 'cancelling');
  assert.equal(calls.length, 1);
  work.reject(calls[0].signal.reason);
  await a.done; await b.done;
  assert.equal(calls.length, 2);
  assert.equal(a.state, 'cancelled');
  const length = changes.length;
  calls[0].update({ state: 'transferring' });
  assert.equal(changes.length, length);
});

test('failed items retry at the tail with the original device and newly acquired result', async () => {
  const work = deferred(), calls = [];
  const queue = createDownloadQueue(target => {
    calls.push(target.device);
    if (calls.length === 1) throw new Error('offline');
    if (calls.length === 2) return work.promise;
    return Promise.resolve({ status: 'saved', id: 'new-receipt' });
  });
  const first = queue.enqueue({ device: 'original', path: 'a' });
  const second = queue.enqueue({ device: 'second', path: 'b' });
  await first.done;
  assert.equal(first.state, 'error');
  const retried = queue.retry(first.id);
  assert.equal(retried.id, first.id);
  assert.equal(retried.error, null);
  assert.equal(retried.state, 'queued');
  work.resolve({ status: 'saved' });
  await second.done; await retried.done;
  assert.deepEqual(calls, ['original', 'second', 'original']);
  assert.equal(retried.result.id, 'new-receipt');
});

test('queues remain independent across WebViews and cancelAll drains only its owner', async () => {
  const first = createDownloadQueue((_target, signal) => new Promise((resolve, reject) => signal.addEventListener('abort', () => reject(signal.reason))));
  const other = createDownloadQueue(() => Promise.resolve({ status: 'saved' }));
  const a = first.enqueue({ path: 'a' }), b = first.enqueue({ path: 'b' });
  const c = other.enqueue({ path: 'c' });
  first.cancelAll();
  await Promise.all([a.done, b.done, c.done]);
  assert.equal(first.pending, 0);
  assert.equal(c.state, 'success');
});

test('late callbacks from a failed attempt cannot update a retry of the same item', async () => {
  const work = deferred(); let lateUpdate, attempts = 0;
  const queue = createDownloadQueue((_target, _signal, update) => {
    if (++attempts === 1) { lateUpdate = update; throw new Error('offline'); }
    return work.promise;
  });
  const item = queue.enqueue({ path: 'a' });
  await item.done;
  const retried = queue.retry(item.id);
  lateUpdate({ state: 'transferring', progress: { received: 999 } });
  assert.equal(retried.state, 'preparing');
  assert.equal(retried.progress, null);
  work.resolve({ status: 'saved' }); await retried.done;
});
