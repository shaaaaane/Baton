import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { showDownloadFeedback } from '../../web/js/project/download-feedback.js';

test('download status survives viewer closure, handles unknown totals and exposes completion actions', () => {
  const dom = new JSDOM('<div class="lab-appearance-dock"></div><div id="viewer"></div>');
  globalThis.document = dom.window.document;
  try {
    showDownloadFeedback({ name: 'brand.html', message: 'Preparing', busy: true });
    const card = document.querySelector('.lab-download-card');
    assert.equal(card.querySelector('progress').hasAttribute('value'), false);
    document.querySelector('#viewer').remove();
    showDownloadFeedback({ progress: { received: 512, total: 1024 }, busy: true });
    assert.match(card.textContent, /50%/);
    showDownloadFeedback({ progress: { received: 1024, total: null }, busy: true });
    assert.doesNotMatch(card.textContent, /%/);
    showDownloadFeedback({ result: { id: '1', status: 'saved' }, message: 'Saved' });
    assert.equal(card.querySelector('progress').hidden, true);
    assert.equal(card.querySelector('[data-action="folder"]').hidden, false);
    card.querySelector('[data-action="dismiss"]').click();
    assert.equal(card.hidden, true);
    document.querySelector('.lab-appearance-toggle').click();
    assert.equal(card.hidden, false);
    showDownloadFeedback({ name: 'next.pdf', message: 'Preparing', busy: true });
    assert.equal(card.querySelector('[data-action="folder"]').hidden, true);
  } finally { dom.window.close(); delete globalThis.document; }
});

function feedbackHarness(t) {
  const dom = new JSDOM('<div class="lab-appearance-dock"></div><button id="outside">Outside</button>');
  globalThis.document = dom.window.document;
  t.mock.timers.enable({ apis: ['setTimeout'] });
  t.after(() => { dom.window.close(); delete globalThis.document; });
  showDownloadFeedback({ id: 'a', name: 'A.pdf', busy: true, cancel: () => {} });
  return { dom, card: document.querySelector('.lab-download-card'), toggle: document.querySelector('.lab-appearance-toggle') };
}

test('successful list auto-dismisses after four seconds and retains its receipt', t => {
  const { card, toggle } = feedbackHarness(t);
  showDownloadFeedback({ id: 'a', result: { status: 'saved', id: 'receipt-a' }, message: 'Saved' });
  t.mock.timers.tick(3999); assert.equal(card.hidden, false);
  t.mock.timers.tick(1); assert.equal(card.hidden, true);
  toggle.click();
  assert.equal(card.hidden, false);
  assert.equal(card.querySelector('[data-action="open"]').hidden, false);
  t.mock.timers.tick(10000); assert.equal(card.hidden, false);
});

test('hover and keyboard focus pause dismissal until the user leaves', t => {
  const { card, dom } = feedbackHarness(t);
  showDownloadFeedback({ id: 'a', result: { status: 'saved', id: 'a' } });
  card.dispatchEvent(new dom.window.Event('mouseenter'));
  t.mock.timers.tick(5000); assert.equal(card.hidden, false);
  card.dispatchEvent(new dom.window.Event('mouseleave'));
  card.querySelector('[data-action="open"]').focus();
  t.mock.timers.tick(5000); assert.equal(card.hidden, false);
  document.getElementById('outside').focus();
  // focusout schedules after focus has actually moved.
  return Promise.resolve().then(() => {
    t.mock.timers.tick(4000); assert.equal(card.hidden, true);
  });
});

test('manual dismissal is respected by progress and success; a new item can reveal the list', t => {
  const { card } = feedbackHarness(t);
  card.querySelector('[data-action="dismiss"]').click();
  showDownloadFeedback({ id: 'a', busy: true, progress: { received: 50, total: 100 } });
  assert.equal(card.hidden, true);
  showDownloadFeedback({ id: 'a', result: { status: 'saved', id: 'a' } });
  assert.equal(card.hidden, true);
  showDownloadFeedback({ id: 'b', name: 'B.pdf', busy: true });
  assert.equal(card.hidden, false);
  assert.equal(card.querySelectorAll('.lab-download-item').length, 2);
});

test('a new queued task cancels the prior success timer and errors stay visible', t => {
  const { card } = feedbackHarness(t);
  showDownloadFeedback({ id: 'a', result: { status: 'saved', id: 'a' } });
  t.mock.timers.tick(3000);
  showDownloadFeedback({ id: 'b', name: 'B.zip', busy: true, message: 'Waiting' });
  t.mock.timers.tick(6000); assert.equal(card.hidden, false);
  card.querySelector('[data-action="dismiss"]').click();
  showDownloadFeedback({ id: 'b', message: 'Offline', attention: true, retry: () => {} });
  assert.equal(card.hidden, false);
  t.mock.timers.tick(10000); assert.equal(card.hidden, false);
});

test('each queued item keeps its own cancellation and retry actions without losing focus', t => {
  const { card } = feedbackHarness(t);
  const actions = [];
  showDownloadFeedback({ id: 'b', name: 'B.zip', busy: true, cancel: () => actions.push('cancel-b') });
  const row = card.querySelector('[data-download-id="b"]');
  const button = row.querySelector('[data-action="cancel"]');
  button.focus();
  showDownloadFeedback({ id: 'a', busy: true, progress: { received: 1, total: 4 } });
  assert.equal(document.activeElement, button);
  button.click();
  showDownloadFeedback({ id: 'b', retry: () => actions.push('retry-b'), message: 'Cancelled' });
  row.querySelector('[data-action="retry"]').click();
  assert.deepEqual(actions, ['cancel-b', 'retry-b']);
});
