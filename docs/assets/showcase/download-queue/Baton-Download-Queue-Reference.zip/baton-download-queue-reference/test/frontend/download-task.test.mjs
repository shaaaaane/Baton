import test from 'node:test';
import assert from 'node:assert/strict';
import { runDownloadStage } from '../../web/js/project/download-task.js';
import { requestWsRpc, handleWsRpcMessage } from '../../web/js/ws-rpc.js';

test('stalled metadata times out, aborts its HTTP request and ignores a late response', async () => {
  let signal, finish;
  await assert.rejects(runDownloadStage(value => {
    signal = value;
    return new Promise(resolve => { finish = resolve; });
  }, { timeout: 15, message: 'metadata timeout' }), /metadata timeout/);
  assert.equal(signal.aborted, true);
  finish({ url: 'https://expired.example/file' });
});

test('cancellation removes the pending file RPC and ignores late frames', async () => {
  let request;
  globalThis.window = { wsSendReliable: message => { request = message; } };
  const controller = new AbortController();
  const pending = runDownloadStage(signal => requestWsRpc({ action: 'project_files', operation: 'download' },
    { signal }), { signal: controller.signal });
  controller.abort();
  await assert.rejects(pending, { name: 'AbortError' });
  assert.equal(handleWsRpcMessage({ ...request, ok: true, key: 'late' }), false);
});

test('already-cancelled operations send nothing and synchronous transport errors leave no RPC entry', async () => {
  const controller = new AbortController();
  controller.abort();
  globalThis.window = { wsSendReliable: () => { throw new Error('must not send'); } };
  await assert.rejects(requestWsRpc({}, { signal: controller.signal }), { name: 'AbortError' });
  let request;
  window.wsSendReliable = value => { request = value; throw new Error('transport closed'); };
  await assert.rejects(requestWsRpc({}), /transport closed/);
  assert.equal(handleWsRpcMessage({ ...request, ok: true }), false);
});
